INSERT INTO users (id, email, name, password_salt, password_hash, created_at) 
VALUES ('b77e1133-341c-4ed1-acf1-c22bbcfa6d61', 'parent@demo.fr', 'Parent démo', 
'34af2f395b5a12e24b3872720834afc4', 'b86fec36cfae640536855b9b11af0950b99652d5a3c7da8b67b0c5a7fb40929e19252d0ce9d8f810a7e8b3af1365f2fe8dc84b50ff74c98e3ea02a77fccfb1ac', NOW());
INSERT INTO families (id, owner_id, name, daily_bonus_xp, daily_bonus_gold, created_at)
VALUES ('fam-60f8c719ce', 'b77e1133-341c-4ed1-acf1-c22bbcfa6d61', 'Chez Alice', 
30, 15, NOW());
INSERT INTO family_members (family_id, user_id, role)
VALUES ('fam-60f8c719ce', 'b77e1133-341c-4ed1-acf1-c22bbcfa6d61', 'owner');
INSERT INTO children (id, family_id, name, xp, gold, pin, created_at)
VALUES ('child-76f10383', 'fam-60f8c719ce', 'Zoé', 
0, 999, '0000', NOW());
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-a73cccb5', 'fam-60f8c719ce', 
'📱', 'Temps écran +30min', 50, 1);
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-dfb2434a', 'fam-60f8c719ce', 
'🎮', 'Session de jeu +1h', 75, 2);
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-6e6753b0', 'fam-60f8c719ce', 
'🍕', 'Pizza au dîner', 100, 2);
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-13a32289', 'fam-60f8c719ce', 
'🚴', 'Sortie à vélo', 120, 3);
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-b5ef858c', 'fam-60f8c719ce', 
'🎬', 'Soirée cinéma en famille', 150, 3);
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-bc01c5f7', 'fam-60f8c719ce', 
'🎪', 'Sortie au parc d''attraction', 200, 4);
INSERT INTO families (id, owner_id, name, daily_bonus_xp, daily_bonus_gold, created_at)
VALUES ('fam-d8d1874732', 'b77e1133-341c-4ed1-acf1-c22bbcfa6d61', 'Chez Alice', 
30, 15, NOW());
INSERT INTO family_members (family_id, user_id, role)
VALUES ('fam-d8d1874732', 'b77e1133-341c-4ed1-acf1-c22bbcfa6d61', 'owner');
INSERT INTO children (id, family_id, name, xp, gold, pin, created_at)
VALUES ('child-f7c004f9', 'fam-d8d1874732', 'Zoé', 
0, 999, '0000', NOW());
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-5bc5a11c', 'fam-d8d1874732', 
'📱', 'Temps écran +30min', 50, 1);
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-34b7a472', 'fam-d8d1874732', 
'🎮', 'Session de jeu +1h', 75, 2);
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-db3355b6', 'fam-d8d1874732', 
'🍕', 'Pizza au dîner', 100, 2);
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-d27312f2', 'fam-d8d1874732', 
'🚴', 'Sortie à vélo', 120, 3);
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-60c852f9', 'fam-d8d1874732', 
'🎬', 'Soirée cinéma en famille', 150, 3);
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-09e12c12', 'fam-d8d1874732', 
'🎪', 'Sortie au parc d''attraction', 200, 4);
INSERT INTO families (id, owner_id, name, daily_bonus_xp, daily_bonus_gold, created_at)
VALUES ('fam-demo', 'b77e1133-341c-4ed1-acf1-c22bbcfa6d61', 'Famille Démo', 
30, 15, NOW());
INSERT INTO family_members (family_id, user_id, role)
VALUES ('fam-demo', 'b77e1133-341c-4ed1-acf1-c22bbcfa6d61', 'owner');
INSERT INTO children (id, family_id, name, xp, gold, pin, created_at)
VALUES ('child-emma-demo', 'fam-demo', 'Emma', 
235, 252, '0000', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-9772d32c', 'child-emma-demo', 'fam-demo', 
'🧹', 'Ranger sa chambre', 20, 10, 
TRUE, TRUE, '2026-10-14T11:38:05.761Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-881c6622', 'child-emma-demo', 'fam-demo', 
'📚', 'Faire ses devoirs', 30, 15, 
TRUE, TRUE, '2026-10-14T11:38:05.761Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-e5816d66', 'child-emma-demo', 'fam-demo', 
'🍽️', 'Mettre la table', 10, 5, 
TRUE, FALSE, '2026-10-15T11:38:05.761Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-efeaab69', 'child-emma-demo', 'fam-demo', 
'🐶', 'Sortir le chien', 16, 8, 
TRUE, FALSE, '2026-10-13T11:38:05.761Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-21a2e5ef', 'child-emma-demo', 'fam-demo', 
'🧹', 'Ranger sa chambre', 20, 10, 
TRUE, TRUE, '2026-10-14T11:38:05.761Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-e581f88e', 'child-emma-demo', 'fam-demo', 
'📚', 'Faire ses devoirs', 30, 15, 
TRUE, TRUE, '2026-10-14T11:38:05.761Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-21bb2ce6', 'child-emma-demo', 'fam-demo', 
'🐶', 'Sortir le chien', 16, 8, 
TRUE, FALSE, '2026-10-13T11:38:05.761Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-a6b3ad15', 'child-emma-demo', 'fam-demo', 
'🧹', 'Ranger sa chambre', 20, 10, 
TRUE, TRUE, '2026-10-14T11:38:05.761Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-f9dd2414', 'child-emma-demo', 'fam-demo', 
'🍽️', 'Mettre la table', 10, 5, 
TRUE, FALSE, '2026-10-15T11:38:05.761Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-35ae96dd', 'child-emma-demo', 'fam-demo', 
'🧹', 'Ranger sa chambre', 20, 10, 
TRUE, TRUE, '2026-10-14T11:38:05.761Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-b626c725', 'child-emma-demo', 'fam-demo', 
'📚', 'Faire ses devoirs', 30, 15, 
TRUE, TRUE, '2026-10-14T11:38:05.761Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-d7b5c962', 'child-emma-demo', 'fam-demo', 
'🐶', 'Sortir le chien', 16, 8, 
TRUE, FALSE, '2026-10-13T11:38:05.761Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-3683a2dc', 'child-emma-demo', 'fam-demo', 
'🍽️', 'Mettre la table', 10, 5, 
TRUE, FALSE, '2026-10-15T11:38:05.761Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-4a68f52b', 'child-emma-demo', 'fam-demo', 
'🧹', 'Ranger sa chambre', 20, 10, 
TRUE, TRUE, '2026-10-14T11:38:05.761Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-41262e86', 'child-emma-demo', 'fam-demo', 
'📚', 'Faire ses devoirs', 30, 15, 
TRUE, TRUE, '2026-10-14T11:38:05.761Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-23efc40f', 'child-emma-demo', 'fam-demo', 
'🐶', 'Sortir le chien', 16, 8, 
TRUE, FALSE, '2026-10-13T11:38:05.761Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-f9a01d39', 'child-emma-demo', 'fam-demo', 
'🛏️', 'Faire son lit', 10, 5, 
TRUE, FALSE, '2026-10-20T11:39:04.584Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-18d1ab58', 'child-emma-demo', 'fam-demo', 
'⭐', 'Brosser les dents', 15, 7, 
TRUE, FALSE, '2026-10-20T11:40:22.380Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-8d9a6b4f', 'child-emma-demo', 'fam-demo', 
'⭐', 'Debarasser la table', 10, 5, 
TRUE, FALSE, '2026-10-20T11:41:06.635Z', NOW());
INSERT INTO grades (id, child_id, family_id, subject, grade, xp, gold, created_at)
VALUES ('grade-7dccbf91', 'child-emma-demo', 'fam-demo', 
'Mathématiques', '16/20', 50, 10, NOW());
INSERT INTO grades (id, child_id, family_id, subject, grade, xp, gold, created_at)
VALUES ('grade-89a19ade', 'child-emma-demo', 'fam-demo', 
'Français', '13/20', 30, 5, NOW());
INSERT INTO grades (id, child_id, family_id, subject, grade, xp, gold, created_at)
VALUES ('grade-75ead280', 'child-emma-demo', 'fam-demo', 
'Histoire-Géo', '', 0, 0, NOW());
INSERT INTO grades (id, child_id, family_id, subject, grade, xp, gold, created_at)
VALUES ('grade-1d996ca7', 'child-emma-demo', 'fam-demo', 
'Anglais', '', 0, 0, NOW());
INSERT INTO children (id, family_id, name, xp, gold, pin, created_at)
VALUES ('child-lucas-demo', 'fam-demo', 'Lucas', 
255, 62, '1111', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-33f8523d', 'child-lucas-demo', 'fam-demo', 
'🛏️', 'Faire son lit', 10, 5, 
TRUE, TRUE, '2026-10-20T11:17:25.111Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-c1c0d84f', 'child-lucas-demo', 'fam-demo', 
'📚', 'Faire ses devoirs', 30, 15, 
FALSE, TRUE, NULL, NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-85c9552f', 'child-lucas-demo', 'fam-demo', 
'🛏️', 'Faire son lit', 10, 5, 
TRUE, FALSE, '2026-10-20T11:17:25.111Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-756bb12d', 'child-lucas-demo', 'fam-demo', 
'🛏️', 'Faire son lit', 10, 5, 
TRUE, FALSE, '2026-10-20T11:17:25.111Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-5cc0add7', 'child-lucas-demo', 'fam-demo', 
'⭐', 'Brosser les dents', 15, 7, 
TRUE, FALSE, '2026-10-20T11:39:54.313Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-47f4fb18', 'child-lucas-demo', 'fam-demo', 
'⭐', 'Debarasser la table', 10, 5, 
FALSE, FALSE, NULL, NOW());
INSERT INTO grades (id, child_id, family_id, subject, grade, xp, gold, created_at)
VALUES ('grade-f62bceea', 'child-lucas-demo', 'fam-demo', 
'Mathématiques', '', 0, 0, NOW());
INSERT INTO grades (id, child_id, family_id, subject, grade, xp, gold, created_at)
VALUES ('grade-758f4d4d', 'child-lucas-demo', 'fam-demo', 
'Français', '', 0, 0, NOW());
INSERT INTO children (id, family_id, name, xp, gold, pin, created_at)
VALUES ('child-test-demo', 'fam-demo', 'Test', 
125, 67, '2222', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-8baaa686', 'child-test-demo', 'fam-demo', 
'🧹', 'Ranger sa chambre', 20, 10, 
TRUE, TRUE, '2026-10-20T11:38:14.146Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-ac886739', 'child-test-demo', 'fam-demo', 
'🛏️', 'Faire son lit', 10, 5, 
TRUE, FALSE, '2026-10-20T11:17:22.519Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-d6d187e3', 'child-test-demo', 'fam-demo', 
'🛏️', 'Faire son lit', 10, 5, 
TRUE, FALSE, '2026-10-20T11:17:22.519Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-3179eb93', 'child-test-demo', 'fam-demo', 
'⭐', 'Brosser les dents', 15, 7, 
TRUE, FALSE, '2026-10-20T11:39:59.099Z', NOW());
INSERT INTO tasks (id, child_id, family_id, icon, name, xp, gold, done, daily, completed_at, created_at)
VALUES ('task-af4c1ce0', 'child-test-demo', 'fam-demo', 
'⭐', 'Debarasser la table', 10, 5, 
FALSE, FALSE, NULL, NOW());
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-411f2cc7', 'fam-demo', 
'🎮', '30 min de jeu vidéo', 50, 1);
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-a3baff42', 'fam-demo', 
'🍿', 'Soirée film + popcorn', 80, 2);
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-7f6de2e7', 'fam-demo', 
'💶', '5€ d''argent de poche', 150, 3);
INSERT INTO families (id, owner_id, name, daily_bonus_xp, daily_bonus_gold, created_at)
VALUES ('fam-e54674058f', 'b77e1133-341c-4ed1-acf1-c22bbcfa6d61', 'Chez Bob', 
30, 15, NOW());
INSERT INTO family_members (family_id, user_id, role)
VALUES ('fam-e54674058f', 'b77e1133-341c-4ed1-acf1-c22bbcfa6d61', 'owner');
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-4081c128', 'fam-e54674058f', 
'📱', 'Temps écran +30min', 50, 1);
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-f1148e7c', 'fam-e54674058f', 
'🎮', 'Session de jeu +1h', 75, 2);
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-e3631acf', 'fam-e54674058f', 
'🍕', 'Pizza au dîner', 100, 2);
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-edc3a211', 'fam-e54674058f', 
'🚴', 'Sortie à vélo', 120, 3);
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-81bb9a3d', 'fam-e54674058f', 
'🎬', 'Soirée cinéma en famille', 150, 3);
INSERT INTO rewards (id, family_id, icon, name, cost, lvl)
VALUES ('reward-8c9ee845', 'fam-e54674058f', 
'🎪', 'Sortie au parc d''attraction', 200, 4);